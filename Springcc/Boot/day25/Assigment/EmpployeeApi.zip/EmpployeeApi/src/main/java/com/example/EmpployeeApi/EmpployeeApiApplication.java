package com.example.EmpployeeApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpployeeApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpployeeApiApplication.class, args);
	}

}
