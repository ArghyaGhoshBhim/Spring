package com.springPractice.restPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
