package com.springPractice.restPractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestPracticeApplication.class, args);
	}

}
