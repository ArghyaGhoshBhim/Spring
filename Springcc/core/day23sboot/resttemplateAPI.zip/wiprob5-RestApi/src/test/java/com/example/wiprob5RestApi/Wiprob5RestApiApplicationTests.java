package com.example.wiprob5RestApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Wiprob5RestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
