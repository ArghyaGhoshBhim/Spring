package com.example.wiprob5RestApi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.wiprob5RestApi.model.Book;

@SpringBootApplication
public class Wiprob5RestApiApplication {

	
	public static void main(String[] args) {
	

		SpringApplication.run(Wiprob5RestApiApplication.class, args);
			
	}

	
	
}
