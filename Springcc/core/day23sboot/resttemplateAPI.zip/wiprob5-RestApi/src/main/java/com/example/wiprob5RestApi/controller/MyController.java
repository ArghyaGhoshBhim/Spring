package com.example.wiprob5RestApi.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.wiprob5RestApi.model.Book;

@RestController
@RequestMapping("books")
public class MyController {

	//http://localhost:1234/books/request
	@GetMapping("/request")
	public String hello()
	{
		return "hello world";
	}
	

	//http://localhost:1234/books/test
	@GetMapping("/test")
	public String hello1()
	{
		return "hello world test";
	}
	
	//http://localhost:1234/books
	@GetMapping()
	public Book getBook()
	{
		return new Book("Rest APIDevelopment", 44);
	}
	
	
	
}
